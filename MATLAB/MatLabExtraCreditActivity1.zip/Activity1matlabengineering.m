diary matlab1_ical.txt
fprintf('Howdy, World')
diary off

