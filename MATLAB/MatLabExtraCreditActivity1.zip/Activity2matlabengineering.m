diary maylab1_ica2.txt
age = input('age pls')
if age < 18
    disp('child')
    
elseif  age > 65
    disp('senior')
    
else
    disp('adult')
end 
diary off
