%NumberofFeetinMiles <- 5280 ft
NumberofFeetinMiles = 5280
%RateofTravel <- 1100ft/s
RateofTravel = 1100
%timey <- real number for time input but user
timey = input(' chill dog what is the time')
%ddistnace <- RateofTravel/NumberofFeetiinMiles * timey
ddistnace =  (RateofTravel/NumberofFeetinMiles) * timey;
%display ddistnace
fprintf(' The cool dog distance is in miles')
display (ddistnace)

